-- =====================================================
-- GUTZO DATABASE MIGRATION - BATCH 3
-- Payment & Coupon Tables
-- =====================================================
-- Run this in Supabase SQL Editor

-- 1. PAYMENTS
CREATE TABLE IF NOT EXISTS public.payments (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    order_id UUID REFERENCES public.orders(id) ON DELETE SET NULL,
    subscription_id UUID REFERENCES public.product_subscriptions(id) ON DELETE SET NULL,
    mode TEXT CHECK (mode IN ('upi', 'card', 'wallet', 'netbanking', 'cod')),
    gateway TEXT CHECK (gateway IN ('phonepe', 'razorpay', 'paytm', 'manual')),
    transaction_id TEXT UNIQUE,
    merchant_order_id TEXT,
    amount DECIMAL(10,2) NOT NULL,
    currency TEXT DEFAULT 'INR',
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'initiated', 'success', 'failed', 'refunded')),
    gateway_response JSONB DEFAULT '{}',
    refund_id TEXT,
    refunded_amount DECIMAL(10,2),
    refunded_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- 2. COUPONS
CREATE TABLE IF NOT EXISTS public.coupons (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    code TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    discount_type TEXT NOT NULL CHECK (discount_type IN ('percentage', 'fixed')),
    discount_value DECIMAL(10,2) NOT NULL,
    minimum_order DECIMAL(10,2) DEFAULT 0,
    maximum_discount DECIMAL(10,2),
    usage_limit INTEGER,
    usage_per_user INTEGER DEFAULT 1,
    used_count INTEGER DEFAULT 0,
    valid_from DATE DEFAULT CURRENT_DATE,
    valid_until DATE,
    is_active BOOLEAN DEFAULT true,
    vendor_id UUID REFERENCES public.vendors(id) ON DELETE CASCADE,
    applicable_categories TEXT[],
    first_order_only BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 3. COUPON_USAGE
CREATE TABLE IF NOT EXISTS public.coupon_usage (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    coupon_id UUID REFERENCES public.coupons(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    order_id UUID REFERENCES public.orders(id) ON DELETE SET NULL,
    discount_applied DECIMAL(10,2) NOT NULL,
    used_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(coupon_id, user_id, order_id)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_payments_order ON public.payments(order_id);
CREATE INDEX IF NOT EXISTS idx_payments_transaction ON public.payments(transaction_id);
CREATE INDEX IF NOT EXISTS idx_payments_status ON public.payments(status);
CREATE INDEX IF NOT EXISTS idx_coupons_code ON public.coupons(code);
CREATE INDEX IF NOT EXISTS idx_coupons_active ON public.coupons(is_active) WHERE is_active = true;
CREATE INDEX IF NOT EXISTS idx_coupon_usage_user ON public.coupon_usage(user_id);

-- Enable RLS
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coupons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coupon_usage ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Public can view active coupons" ON public.coupons FOR SELECT USING (is_active = true);

COMMENT ON TABLE public.payments IS 'Payment transactions for orders and subscriptions';
COMMENT ON TABLE public.coupons IS 'Discount codes - platform-wide or vendor-specific';
COMMENT ON TABLE public.coupon_usage IS 'Tracks which user used which coupon';

-- Sample coupons
INSERT INTO public.coupons (code, name, description, discount_type, discount_value, minimum_order, maximum_discount, first_order_only) VALUES
('WELCOME50', 'Welcome Offer', '50% off on first order', 'percentage', 50, 200, 150, true),
('HEALTHY20', 'Healthy Discount', 'Flat ₹20 off', 'fixed', 20, 100, NULL, false),
('PROTEIN30', 'Protein Pack', '30% off on protein meals', 'percentage', 30, 300, 100, false)
ON CONFLICT (code) DO NOTHING;
