-- =====================================================
-- GUTZO DATABASE MIGRATION - BATCH 5
-- Reviews & Notifications
-- =====================================================
-- Run this in Supabase SQL Editor

-- 1. REVIEWS
CREATE TABLE IF NOT EXISTS public.reviews (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    vendor_id UUID REFERENCES public.vendors(id) ON DELETE CASCADE,
    product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
    order_id UUID REFERENCES public.orders(id) ON DELETE SET NULL,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    images TEXT[] DEFAULT '{}',
    is_verified_purchase BOOLEAN DEFAULT false,
    status TEXT DEFAULT 'published' CHECK (status IN ('pending', 'published', 'hidden', 'removed')),
    vendor_reply TEXT,
    replied_at TIMESTAMPTZ,
    helpful_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(user_id, order_id, product_id)
);

-- 2. REVIEW_VOTES
CREATE TABLE IF NOT EXISTS public.review_votes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    review_id UUID REFERENCES public.reviews(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    is_helpful BOOLEAN NOT NULL,
    created_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(review_id, user_id)
);

-- 3. NOTIFICATIONS
CREATE TABLE IF NOT EXISTS public.notifications (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    type TEXT NOT NULL CHECK (type IN (
        'order_placed', 'order_confirmed', 'order_preparing', 'order_ready', 
        'order_delivered', 'order_cancelled',
        'subscription_reminder', 'subscription_renewed', 'subscription_paused',
        'payment_success', 'payment_failed',
        'promo', 'system'
    )),
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    data JSONB DEFAULT '{}',
    is_read BOOLEAN DEFAULT false,
    read_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 4. NOTIFICATION_PREFERENCES
CREATE TABLE IF NOT EXISTS public.notification_preferences (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE UNIQUE,
    order_updates BOOLEAN DEFAULT true,
    subscription_alerts BOOLEAN DEFAULT true,
    promotional BOOLEAN DEFAULT true,
    review_requests BOOLEAN DEFAULT true,
    channel TEXT DEFAULT 'push' CHECK (channel IN ('push', 'sms', 'email', 'all')),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_reviews_vendor ON public.reviews(vendor_id);
CREATE INDEX IF NOT EXISTS idx_reviews_product ON public.reviews(product_id);
CREATE INDEX IF NOT EXISTS idx_reviews_user ON public.reviews(user_id);
CREATE INDEX IF NOT EXISTS idx_reviews_status ON public.reviews(status) WHERE status = 'published';
CREATE INDEX IF NOT EXISTS idx_notifications_user ON public.notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON public.notifications(user_id) WHERE is_read = false;

-- Enable RLS
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.review_votes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notification_preferences ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Public can view published reviews" ON public.reviews FOR SELECT USING (status = 'published');
CREATE POLICY "Users can view own notifications" ON public.notifications FOR SELECT USING (true);

COMMENT ON TABLE public.reviews IS 'User reviews for vendors and products';
COMMENT ON TABLE public.review_votes IS 'Helpful/Not helpful votes on reviews';
COMMENT ON TABLE public.notifications IS 'User notifications for orders, subscriptions, promos';
COMMENT ON TABLE public.notification_preferences IS 'User notification settings';
