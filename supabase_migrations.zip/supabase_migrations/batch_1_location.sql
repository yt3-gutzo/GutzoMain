-- =====================================================
-- GUTZO DATABASE MIGRATION - BATCH 1
-- Location & Delivery Tables
-- =====================================================
-- Run this in Supabase SQL Editor

-- 1. DELIVERY_ZONES
CREATE TABLE IF NOT EXISTS public.delivery_zones (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    city TEXT NOT NULL DEFAULT 'Coimbatore',
    state TEXT DEFAULT 'Tamil Nadu',
    center_lat DECIMAL(10,8),
    center_lng DECIMAL(11,8),
    radius_km DECIMAL(5,2),
    polygon JSONB,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 2. VENDOR_DELIVERY_ZONES
CREATE TABLE IF NOT EXISTS public.vendor_delivery_zones (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    vendor_id UUID REFERENCES public.vendors(id) ON DELETE CASCADE,
    zone_id UUID REFERENCES public.delivery_zones(id) ON DELETE CASCADE,
    delivery_fee DECIMAL(10,2) DEFAULT 0,
    min_delivery_time INTEGER DEFAULT 20,
    max_delivery_time INTEGER DEFAULT 35,
    minimum_order DECIMAL(10,2) DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(vendor_id, zone_id)
);

-- 3. RIDER (Future)
CREATE TABLE IF NOT EXISTS public.riders (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    phone TEXT UNIQUE NOT NULL,
    email TEXT,
    profile_image TEXT,
    vehicle_type TEXT CHECK (vehicle_type IN ('bike', 'scooter', 'cycle', 'car')),
    vehicle_number TEXT,
    license_number TEXT,
    active_status TEXT DEFAULT 'offline' CHECK (active_status IN ('online', 'offline', 'busy')),
    current_lat DECIMAL(10,8),
    current_lng DECIMAL(11,8),
    current_order_id UUID,
    total_deliveries INTEGER DEFAULT 0,
    avg_rating DECIMAL(2,1) DEFAULT 0,
    bank_account JSONB,
    is_verified BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_delivery_zones_city ON public.delivery_zones(city);
CREATE INDEX IF NOT EXISTS idx_vendor_zones_vendor ON public.vendor_delivery_zones(vendor_id);
CREATE INDEX IF NOT EXISTS idx_riders_phone ON public.riders(phone);

-- Enable RLS
ALTER TABLE public.delivery_zones ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vendor_delivery_zones ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.riders ENABLE ROW LEVEL SECURITY;

-- Public read policies
CREATE POLICY "Public can view active zones" ON public.delivery_zones FOR SELECT USING (is_active = true);
CREATE POLICY "Public can view vendor zones" ON public.vendor_delivery_zones FOR SELECT USING (is_active = true);

COMMENT ON TABLE public.delivery_zones IS 'Delivery zones in Coimbatore area';
COMMENT ON TABLE public.vendor_delivery_zones IS 'Vendor to zone mapping with custom fees';
COMMENT ON TABLE public.riders IS 'Delivery partners (future feature)';

-- Seed some delivery zones for Coimbatore
INSERT INTO public.delivery_zones (name, city, center_lat, center_lng, radius_km) VALUES
('RS Puram', 'Coimbatore', 11.0168, 76.9558, 3.0),
('Gandhipuram', 'Coimbatore', 11.0178, 76.9674, 2.5),
('Peelamedu', 'Coimbatore', 11.0284, 77.0054, 3.0),
('Saibaba Colony', 'Coimbatore', 11.0287, 76.9516, 2.0),
('Race Course', 'Coimbatore', 11.0136, 76.9629, 2.5),
('Singanallur', 'Coimbatore', 10.9972, 77.0353, 3.5)
ON CONFLICT DO NOTHING;
