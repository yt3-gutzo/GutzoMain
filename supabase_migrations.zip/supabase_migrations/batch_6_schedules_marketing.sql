-- =====================================================
-- GUTZO DATABASE MIGRATION - BATCH 6
-- Vendor Schedules & Marketing
-- =====================================================
-- Run this in Supabase SQL Editor

-- 1. VENDOR_SCHEDULES (Weekly Hours)
CREATE TABLE IF NOT EXISTS public.vendor_schedules (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    vendor_id UUID REFERENCES public.vendors(id) ON DELETE CASCADE,
    day_of_week INTEGER NOT NULL CHECK (day_of_week >= 0 AND day_of_week <= 6),
    opening_time TIME,
    closing_time TIME,
    is_closed BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(vendor_id, day_of_week)
);

-- 2. VENDOR_SPECIAL_HOURS (Holidays)
CREATE TABLE IF NOT EXISTS public.vendor_special_hours (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    vendor_id UUID REFERENCES public.vendors(id) ON DELETE CASCADE,
    special_date DATE NOT NULL,
    opening_time TIME,
    closing_time TIME,
    is_closed BOOLEAN DEFAULT false,
    reason TEXT,
    created_at TIMESTAMPTZ DEFAULT now(),
    UNIQUE(vendor_id, special_date)
);

-- 3. PROMO_BANNERS
CREATE TABLE IF NOT EXISTS public.promo_banners (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    subtitle TEXT,
    image_url TEXT NOT NULL,
    mobile_image_url TEXT,
    link_type TEXT CHECK (link_type IN ('vendor', 'product', 'category', 'meal_plan', 'url')),
    link_target_id UUID,
    link_url TEXT,
    position TEXT DEFAULT 'hero' CHECK (position IN ('hero', 'middle', 'bottom')),
    sort_order INTEGER DEFAULT 0,
    start_date TIMESTAMPTZ DEFAULT now(),
    end_date TIMESTAMPTZ,
    is_active BOOLEAN DEFAULT true,
    clicks INTEGER DEFAULT 0,
    impressions INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 4. REFERRALS
CREATE TABLE IF NOT EXISTS public.referrals (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    referrer_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    referee_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    referral_code TEXT NOT NULL,
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'expired')),
    referrer_reward DECIMAL(10,2) DEFAULT 50,
    referee_reward DECIMAL(10,2) DEFAULT 50,
    first_order_id UUID REFERENCES public.orders(id) ON DELETE SET NULL,
    completed_at TIMESTAMPTZ,
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 5. WAITLIST
CREATE TABLE IF NOT EXISTS public.waitlist (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    type TEXT NOT NULL CHECK (type IN ('product', 'vendor', 'zone')),
    target_id UUID NOT NULL,
    user_phone TEXT,
    user_email TEXT,
    notified BOOLEAN DEFAULT false,
    notified_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_vendor_schedules_vendor ON public.vendor_schedules(vendor_id);
CREATE INDEX IF NOT EXISTS idx_vendor_special_hours_vendor ON public.vendor_special_hours(vendor_id);
CREATE INDEX IF NOT EXISTS idx_vendor_special_hours_date ON public.vendor_special_hours(special_date);
CREATE INDEX IF NOT EXISTS idx_promo_banners_active ON public.promo_banners(is_active) WHERE is_active = true;
CREATE INDEX IF NOT EXISTS idx_referrals_code ON public.referrals(referral_code);
CREATE INDEX IF NOT EXISTS idx_waitlist_target ON public.waitlist(type, target_id);

-- Enable RLS
ALTER TABLE public.vendor_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vendor_special_hours ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.promo_banners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.waitlist ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Public can view schedules" ON public.vendor_schedules FOR SELECT USING (true);
CREATE POLICY "Public can view special hours" ON public.vendor_special_hours FOR SELECT USING (true);
CREATE POLICY "Public can view active banners" ON public.promo_banners FOR SELECT USING (is_active = true);

COMMENT ON TABLE public.vendor_schedules IS 'Vendor weekly operating hours';
COMMENT ON TABLE public.vendor_special_hours IS 'Holiday closures and special hours';
COMMENT ON TABLE public.promo_banners IS 'Homepage promotional banners';
COMMENT ON TABLE public.referrals IS 'User referral tracking';
COMMENT ON TABLE public.waitlist IS 'Notify users when product/vendor becomes available';
