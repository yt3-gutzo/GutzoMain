-- =====================================================
-- GUTZO DATABASE MIGRATION - BATCH 2
-- Product Variants & Addons
-- =====================================================
-- Run this in Supabase SQL Editor

-- 1. PRODUCT_VARIANT (Size Options)
CREATE TABLE IF NOT EXISTS public.product_variants (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    product_id UUID REFERENCES public.products(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    calories INTEGER,
    image TEXT,
    is_default BOOLEAN DEFAULT false,
    is_available BOOLEAN DEFAULT true,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 2. PRODUCT_ADDON (Extra Toppings)
CREATE TABLE IF NOT EXISTS public.product_addons (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    product_id UUID REFERENCES public.products(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    image TEXT,
    is_veg BOOLEAN DEFAULT true,
    max_quantity INTEGER DEFAULT 1,
    is_available BOOLEAN DEFAULT true,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_product_variants_product ON public.product_variants(product_id);
CREATE INDEX IF NOT EXISTS idx_product_addons_product ON public.product_addons(product_id);

-- Enable RLS
ALTER TABLE public.product_variants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.product_addons ENABLE ROW LEVEL SECURITY;

-- Public read policies
CREATE POLICY "Public can view variants" ON public.product_variants FOR SELECT USING (is_available = true);
CREATE POLICY "Public can view addons" ON public.product_addons FOR SELECT USING (is_available = true);

COMMENT ON TABLE public.product_variants IS 'Product size options like Small, Medium, Large';
COMMENT ON TABLE public.product_addons IS 'Extra toppings and additions for products';
