-- =====================================================
-- GUTZO DATABASE MIGRATION - BATCH 4
-- Meal Plan Tables
-- =====================================================
-- Run this in Supabase SQL Editor

-- 1. MEAL_PLANS
CREATE TABLE IF NOT EXISTS public.meal_plans (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    vendor_id UUID REFERENCES public.vendors(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    thumbnail TEXT,
    banner_url TEXT,
    video_url TEXT,
    price_display TEXT NOT NULL,
    price_per_day DECIMAL(10,2),
    price_per_week DECIMAL(10,2),
    trial_price DECIMAL(10,2),
    schedule TEXT NOT NULL,
    features TEXT[] DEFAULT '{}',
    plan_type TEXT CHECK (plan_type IN ('weight_loss', 'muscle_gain', 'balanced', 'detox', 'keto', 'general')),
    dietary_type TEXT CHECK (dietary_type IN ('veg', 'non-veg', 'vegan', 'eggetarian')),
    calories_per_day INTEGER,
    includes_breakfast BOOLEAN DEFAULT false,
    includes_lunch BOOLEAN DEFAULT true,
    includes_dinner BOOLEAN DEFAULT true,
    includes_snacks BOOLEAN DEFAULT false,
    rating DECIMAL(2,1) DEFAULT 4.5,
    review_count INTEGER DEFAULT 0,
    min_duration_days INTEGER DEFAULT 7,
    max_duration_days INTEGER DEFAULT 90,
    terms_conditions TEXT,
    is_active BOOLEAN DEFAULT true,
    is_featured BOOLEAN DEFAULT false,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- 2. MEAL_PLAN_DAY_MENU (Day-wise Menu)
CREATE TABLE IF NOT EXISTS public.meal_plan_day_menu (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    meal_plan_id UUID REFERENCES public.meal_plans(id) ON DELETE CASCADE,
    day_of_week INTEGER CHECK (day_of_week >= 0 AND day_of_week <= 6),
    day_name TEXT,
    day_theme TEXT,
    breakfast_product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
    breakfast_image TEXT,
    lunch_product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
    lunch_image TEXT,
    dinner_product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
    dinner_image TEXT,
    snack_product_id UUID REFERENCES public.products(id) ON DELETE SET NULL,
    snack_image TEXT,
    total_calories INTEGER,
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT now()
);

-- 3. MEAL_PLAN_SUBSCRIPTIONS (User Joined a Plan)
CREATE TABLE IF NOT EXISTS public.meal_plan_subscriptions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    meal_plan_id UUID REFERENCES public.meal_plans(id) ON DELETE SET NULL,
    chosen_meals TEXT[] DEFAULT '{lunch,dinner}',
    chosen_days INTEGER[] DEFAULT '{1,2,3,4,5,6}',
    custom_times JSONB DEFAULT '{}',
    duration TEXT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE,
    total_amount DECIMAL(10,2) NOT NULL,
    delivery_address JSONB NOT NULL,
    status TEXT DEFAULT 'active' CHECK (status IN ('active', 'paused', 'cancelled', 'completed')),
    payment_id TEXT,
    payment_status TEXT DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT now(),
    updated_at TIMESTAMPTZ DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_meal_plans_vendor ON public.meal_plans(vendor_id);
CREATE INDEX IF NOT EXISTS idx_meal_plans_active ON public.meal_plans(is_active) WHERE is_active = true;
CREATE INDEX IF NOT EXISTS idx_meal_plan_day_menu_plan ON public.meal_plan_day_menu(meal_plan_id);
CREATE INDEX IF NOT EXISTS idx_meal_plan_subs_user ON public.meal_plan_subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_meal_plan_subs_status ON public.meal_plan_subscriptions(status);

-- Enable RLS
ALTER TABLE public.meal_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.meal_plan_day_menu ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.meal_plan_subscriptions ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Public can view active meal plans" ON public.meal_plans FOR SELECT USING (is_active = true);
CREATE POLICY "Public can view meal plan menus" ON public.meal_plan_day_menu FOR SELECT USING (true);

COMMENT ON TABLE public.meal_plans IS 'Weekly/Monthly meal plans like Protein Power, Balanced Diet';
COMMENT ON TABLE public.meal_plan_day_menu IS 'Day-wise menu for each meal plan';
COMMENT ON TABLE public.meal_plan_subscriptions IS 'User subscriptions to meal plans';

-- Sample meal plans
INSERT INTO public.meal_plans (title, price_display, price_per_day, schedule, features, dietary_type, includes_lunch, includes_dinner, rating, is_featured, sort_order) VALUES
('Protein Power', '₹89/day', 89.00, 'Mon – Sat · Lunch/Dinner', ARRAY['Curated, chef-cooked dishes', 'Daily menu variety', 'Free delivery on every order'], 'non-veg', true, true, 4.6, true, 1),
('Balanced Meal', '₹89/day', 89.00, 'Mon – Sat · Lunch/Dinner', ARRAY['Curated, chef-cooked dishes', 'Daily menu variety', 'Free delivery on every order'], 'veg', true, true, 4.8, true, 2),
('Veggie Delight', '₹85/day', 85.00, 'Mon – Sat · Lunch/Dinner', ARRAY['Fresh vegetarian dishes', 'Daily menu variety', 'Free delivery on every order'], 'veg', true, true, 4.5, false, 3),
('Keto Power', '₹99/day', 99.00, 'Mon – Sat · Lunch/Dinner', ARRAY['Low carb meals', 'High protein', 'Free delivery'], 'non-veg', true, true, 4.7, false, 4)
ON CONFLICT DO NOTHING;
