-- =====================================================
-- GUTZO DATABASE MIGRATION - BATCH 8
-- Alter Existing Tables (Add Missing Columns)
-- =====================================================
-- Run this in Supabase SQL Editor

-- Add missing columns to USERS table
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS profile_image TEXT;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS date_of_birth DATE;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS gender TEXT;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS language_preference TEXT DEFAULT 'en';
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS dietary_preference TEXT[];
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS allergies TEXT[];
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS health_goals TEXT[];
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS referral_code TEXT;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS referred_by UUID;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS total_orders INTEGER DEFAULT 0;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS total_spent DECIMAL(12,2) DEFAULT 0;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS loyalty_points INTEGER DEFAULT 0;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS membership_tier TEXT DEFAULT 'bronze';
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS device_tokens TEXT[];
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS last_order_at TIMESTAMPTZ;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS last_login_at TIMESTAMPTZ;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS is_blocked BOOLEAN DEFAULT false;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS blocked_reason TEXT;

-- Add missing columns to VENDORS table
ALTER TABLE public.vendors ADD COLUMN IF NOT EXISTS logo TEXT;
ALTER TABLE public.vendors ADD COLUMN IF NOT EXISTS banner_url TEXT;
ALTER TABLE public.vendors ADD COLUMN IF NOT EXISTS total_orders INTEGER DEFAULT 0;
ALTER TABLE public.vendors ADD COLUMN IF NOT EXISTS total_reviews INTEGER DEFAULT 0;
ALTER TABLE public.vendors ADD COLUMN IF NOT EXISTS whatsapp_number TEXT;
ALTER TABLE public.vendors ADD COLUMN IF NOT EXISTS email TEXT;
ALTER TABLE public.vendors ADD COLUMN IF NOT EXISTS is_open BOOLEAN DEFAULT true;
ALTER TABLE public.vendors ADD COLUMN IF NOT EXISTS is_verified BOOLEAN DEFAULT false;
ALTER TABLE public.vendors ADD COLUMN IF NOT EXISTS gst_number TEXT;
ALTER TABLE public.vendors ADD COLUMN IF NOT EXISTS fssai_license TEXT;
ALTER TABLE public.vendors ADD COLUMN IF NOT EXISTS bank_account JSONB;
ALTER TABLE public.vendors ADD COLUMN IF NOT EXISTS commission_rate DECIMAL(5,2) DEFAULT 15;
ALTER TABLE public.vendors ADD COLUMN IF NOT EXISTS payout_frequency TEXT DEFAULT 'weekly';
ALTER TABLE public.vendors ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'approved';

-- Add missing columns to PRODUCTS table
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS thumbnail TEXT;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS gallery_images TEXT[];
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS video_url TEXT;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS type TEXT DEFAULT 'veg';
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS discount_price DECIMAL(10,2);
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS discount_percent INTEGER;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS is_bestseller BOOLEAN DEFAULT false;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS calories INTEGER;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS serves INTEGER DEFAULT 1;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS stock_quantity INTEGER;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS max_order_qty INTEGER DEFAULT 10;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS min_order_qty INTEGER DEFAULT 1;
ALTER TABLE public.products ADD COLUMN IF NOT EXISTS available_days INTEGER[];

-- Add missing columns to CATEGORIES table
ALTER TABLE public.categories ADD COLUMN IF NOT EXISTS banner_url TEXT;
ALTER TABLE public.categories ADD COLUMN IF NOT EXISTS parent_category_id UUID;
ALTER TABLE public.categories ADD COLUMN IF NOT EXISTS slug TEXT;
ALTER TABLE public.categories ADD COLUMN IF NOT EXISTS is_featured BOOLEAN DEFAULT false;

-- Add missing columns to ORDERS table
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS rider_id UUID;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS tip_amount DECIMAL(10,2) DEFAULT 0;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS delivery_otp TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS cancelled_by TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS cancellation_reason TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS refund_status TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS refund_amount DECIMAL(10,2);
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS rating INTEGER;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS feedback TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS feedback_at TIMESTAMPTZ;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS invoice_number TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS invoice_url TEXT;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS order_source TEXT DEFAULT 'app';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS device_type TEXT;

-- Add missing columns to USER_ADDRESSES table
ALTER TABLE public.user_addresses ADD COLUMN IF NOT EXISTS custom_label TEXT;
ALTER TABLE public.user_addresses ADD COLUMN IF NOT EXISTS zipcode TEXT;
ALTER TABLE public.user_addresses ADD COLUMN IF NOT EXISTS delivery_notes TEXT;

-- Add missing columns to PRODUCT_SUBSCRIPTIONS table
ALTER TABLE public.product_subscriptions ADD COLUMN IF NOT EXISTS menu_ids UUID[];
ALTER TABLE public.product_subscriptions ADD COLUMN IF NOT EXISTS next_delivery_date DATE;
ALTER TABLE public.product_subscriptions ADD COLUMN IF NOT EXISTS per_delivery_amount DECIMAL(10,2);
ALTER TABLE public.product_subscriptions ADD COLUMN IF NOT EXISTS auto_renew BOOLEAN DEFAULT false;
ALTER TABLE public.product_subscriptions ADD COLUMN IF NOT EXISTS pause_start_date DATE;
ALTER TABLE public.product_subscriptions ADD COLUMN IF NOT EXISTS pause_end_date DATE;
ALTER TABLE public.product_subscriptions ADD COLUMN IF NOT EXISTS pause_reason TEXT;
ALTER TABLE public.product_subscriptions ADD COLUMN IF NOT EXISTS skip_dates DATE[];

COMMENT ON COLUMN public.users.referral_code IS 'User unique referral code for inviting friends';
COMMENT ON COLUMN public.users.loyalty_points IS 'Points earned from orders';
COMMENT ON COLUMN public.vendors.commission_rate IS 'Platform commission percentage';
COMMENT ON COLUMN public.products.type IS 'veg, non-veg, or egg';
COMMENT ON COLUMN public.orders.delivery_otp IS '4-digit verification code for delivery';
