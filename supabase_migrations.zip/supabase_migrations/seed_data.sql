-- =====================================================
-- GUTZO DATABASE - SEED DATA
-- Test entries for all tables
-- Run this AFTER all batch migrations
-- =====================================================

-- =====================================================
-- 1. DELIVERY ZONES (if not already seeded)
-- =====================================================
INSERT INTO public.delivery_zones (id, name, city, center_lat, center_lng, radius_km, is_active) VALUES
('d1000001-0000-4000-8000-000000000001', 'RS Puram', 'Coimbatore', 11.0168, 76.9558, 3.0, true),
('d1000002-0000-4000-8000-000000000002', 'Gandhipuram', 'Coimbatore', 11.0178, 76.9674, 2.5, true),
('d1000003-0000-4000-8000-000000000003', 'Peelamedu', 'Coimbatore', 11.0284, 77.0054, 3.0, true),
('d1000004-0000-4000-8000-000000000004', 'Saibaba Colony', 'Coimbatore', 11.0287, 76.9516, 2.0, true),
('d1000005-0000-4000-8000-000000000005', 'Race Course', 'Coimbatore', 11.0136, 76.9629, 2.5, true)
ON CONFLICT DO NOTHING;

-- =====================================================
-- 2. VENDOR DELIVERY ZONES
-- =====================================================
INSERT INTO public.vendor_delivery_zones (vendor_id, zone_id, delivery_fee, min_delivery_time, max_delivery_time, minimum_order, is_active)
SELECT v.id, z.id, 25.00, 20, 35, 100, true
FROM public.vendors v, public.delivery_zones z
WHERE v.is_active = true
ON CONFLICT DO NOTHING;

-- =====================================================
-- 3. PRODUCT VARIANTS (for existing products)
-- =====================================================
INSERT INTO public.product_variants (id, product_id, name, price, is_default, is_available, sort_order)
SELECT 
  gen_random_uuid(),
  p.id,
  'Regular',
  p.price,
  true,
  true,
  1
FROM public.products p
WHERE NOT EXISTS (SELECT 1 FROM public.product_variants pv WHERE pv.product_id = p.id)
LIMIT 10;

-- Add Medium and Large variants
INSERT INTO public.product_variants (id, product_id, name, price, is_default, is_available, sort_order)
SELECT 
  gen_random_uuid(),
  p.id,
  'Medium',
  p.price + 30,
  false,
  true,
  2
FROM public.products p
WHERE EXISTS (SELECT 1 FROM public.product_variants pv WHERE pv.product_id = p.id AND pv.name = 'Regular')
LIMIT 10;

INSERT INTO public.product_variants (id, product_id, name, price, is_default, is_available, sort_order)
SELECT 
  gen_random_uuid(),
  p.id,
  'Large',
  p.price + 60,
  false,
  true,
  3
FROM public.products p
WHERE EXISTS (SELECT 1 FROM public.product_variants pv WHERE pv.product_id = p.id AND pv.name = 'Regular')
LIMIT 10;

-- =====================================================
-- 4. PRODUCT ADDONS (for existing products)
-- =====================================================
INSERT INTO public.product_addons (id, product_id, name, price, is_veg, max_quantity, is_available, sort_order)
SELECT 
  gen_random_uuid(),
  p.id,
  'Extra Cheese',
  25.00,
  true,
  2,
  true,
  1
FROM public.products p
WHERE NOT EXISTS (SELECT 1 FROM public.product_addons pa WHERE pa.product_id = p.id)
LIMIT 10;

INSERT INTO public.product_addons (id, product_id, name, price, is_veg, max_quantity, is_available, sort_order)
SELECT 
  gen_random_uuid(),
  p.id,
  'Extra Sauce',
  15.00,
  true,
  3,
  true,
  2
FROM public.products p
WHERE EXISTS (SELECT 1 FROM public.product_addons pa WHERE pa.product_id = p.id AND pa.name = 'Extra Cheese')
LIMIT 10;

-- =====================================================
-- 5. COUPONS
-- =====================================================
INSERT INTO public.coupons (id, code, name, description, discount_type, discount_value, minimum_order, maximum_discount, usage_limit, valid_until, is_active, first_order_only) VALUES
('c1000001-0000-4000-8000-000000000001', 'WELCOME50', 'Welcome Offer', '50% off on your first order!', 'percentage', 50, 200, 150, 1000, '2025-12-31', true, true),
('c1000002-0000-4000-8000-000000000002', 'FLAT100', 'Flat 100 Off', 'Flat 100 off on orders above 500', 'fixed', 100, 500, NULL, 500, '2025-12-31', true, false),
('c1000003-0000-4000-8000-000000000003', 'HEALTHY20', 'Healthy Discount', '20% off on all healthy meals', 'percentage', 20, 300, 80, NULL, '2025-12-31', true, false),
('c1000004-0000-4000-8000-000000000004', 'PROTEIN30', 'Protein Pack Deal', '30% off on protein-rich meals', 'percentage', 30, 400, 120, 200, '2025-12-31', true, false),
('c1000005-0000-4000-8000-000000000005', 'FREESHIP', 'Free Delivery', 'Free delivery on orders above 250', 'fixed', 30, 250, NULL, NULL, '2025-12-31', true, false)
ON CONFLICT (code) DO NOTHING;

-- =====================================================
-- 6. MEAL PLANS
-- =====================================================
INSERT INTO public.meal_plans (id, title, description, thumbnail, price_display, price_per_day, price_per_week, trial_price, schedule, features, plan_type, dietary_type, includes_lunch, includes_dinner, rating, is_active, is_featured, sort_order) VALUES
('a1000001-0000-4000-8000-000000000001', 'Protein Power', 'High protein meals for fitness enthusiasts', '/assets/mealplans/proteinpower.png', '89/day', 89.00, 534.00, 299.00, 'Mon to Sat Lunch Dinner', ARRAY['Curated chef-cooked dishes', 'Daily menu variety', 'Free delivery on every order', '30g+ protein per meal'], 'muscle_gain', 'non-veg', true, true, 4.6, true, true, 1),
('a1000002-0000-4000-8000-000000000002', 'Balanced Meal', 'Perfectly balanced nutrition for daily wellness', '/assets/mealplans/balanced.png', '89/day', 89.00, 534.00, 299.00, 'Mon to Sat Lunch Dinner', ARRAY['Curated chef-cooked dishes', 'Daily menu variety', 'Free delivery on every order', 'Balanced macros'], 'balanced', 'veg', true, true, 4.8, true, true, 2),
('a1000003-0000-4000-8000-000000000003', 'Veggie Delight', 'Fresh vegetarian meals with seasonal produce', '/assets/mealplans/veggiedelight.png', '85/day', 85.00, 510.00, 279.00, 'Mon to Sat Lunch Dinner', ARRAY['100% vegetarian', 'Fresh ingredients', 'Free delivery', 'Low oil cooking'], 'balanced', 'veg', true, true, 4.5, true, false, 3),
('a1000004-0000-4000-8000-000000000004', 'Keto Power', 'Low carb high fat ketogenic meals', '/assets/mealplans/keto.png', '99/day', 99.00, 594.00, 349.00, 'Mon to Sat Lunch Dinner', ARRAY['Under 20g carbs', 'High healthy fats', 'Keto-friendly ingredients', 'No sugar added'], 'keto', 'non-veg', true, true, 4.7, true, false, 4),
('a1000005-0000-4000-8000-000000000005', 'Weight Loss', 'Calorie-controlled meals for weight management', '/assets/mealplans/weightloss.png', '95/day', 95.00, 570.00, 329.00, 'Mon to Sat Lunch Dinner', ARRAY['500-600 cal per meal', 'High fiber', 'Portion controlled', 'Nutritionist approved'], 'weight_loss', 'veg', true, true, 4.4, true, true, 5)
ON CONFLICT DO NOTHING;

-- =====================================================
-- 7. MEAL PLAN DAY MENU
-- =====================================================
INSERT INTO public.meal_plan_day_menu (meal_plan_id, day_of_week, day_name, day_theme, total_calories) VALUES
('a1000001-0000-4000-8000-000000000001', 0, 'Sunday', 'Rest Day Special', 1200),
('a1000001-0000-4000-8000-000000000001', 1, 'Monday', 'Muscle Monday', 1400),
('a1000001-0000-4000-8000-000000000001', 2, 'Tuesday', 'Protein Tuesday', 1350),
('a1000001-0000-4000-8000-000000000001', 3, 'Wednesday', 'Wellness Wednesday', 1300),
('a1000001-0000-4000-8000-000000000001', 4, 'Thursday', 'Thriving Thursday', 1400),
('a1000001-0000-4000-8000-000000000001', 5, 'Friday', 'Fitness Friday', 1350),
('a1000001-0000-4000-8000-000000000001', 6, 'Saturday', 'Strong Saturday', 1400),
('a1000002-0000-4000-8000-000000000002', 1, 'Monday', 'Fresh Start', 1100),
('a1000002-0000-4000-8000-000000000002', 2, 'Tuesday', 'Energy Boost', 1150),
('a1000002-0000-4000-8000-000000000002', 3, 'Wednesday', 'Mid-week Balance', 1100),
('a1000002-0000-4000-8000-000000000002', 4, 'Thursday', 'Nourish Day', 1150),
('a1000002-0000-4000-8000-000000000002', 5, 'Friday', 'Vitality Friday', 1100),
('a1000002-0000-4000-8000-000000000002', 6, 'Saturday', 'Weekend Wellness', 1200)
ON CONFLICT DO NOTHING;

-- =====================================================
-- 8. PROMO BANNERS
-- =====================================================
INSERT INTO public.promo_banners (id, title, subtitle, image_url, mobile_image_url, link_type, position, sort_order, is_active) VALUES
('b1000001-0000-4000-8000-000000000001', 'Welcome to Gutzo!', 'Healthy food delivered fresh', '/assets/banners/hero-welcome.png', '/assets/banners/hero-welcome-mobile.png', 'url', 'hero', 1, true),
('b1000002-0000-4000-8000-000000000002', 'Protein Power Meals', 'Get 30g+ protein with every meal', '/assets/banners/protein-power.png', '/assets/banners/protein-power-mobile.png', 'meal_plan', 'hero', 2, true),
('b1000003-0000-4000-8000-000000000003', 'First Order 50% OFF', 'Use code WELCOME50', '/assets/banners/first-order.png', '/assets/banners/first-order-mobile.png', 'url', 'middle', 1, true),
('b1000004-0000-4000-8000-000000000004', 'Weekly Meal Plans', 'Subscribe and save more', '/assets/banners/meal-plans.png', '/assets/banners/meal-plans-mobile.png', 'meal_plan', 'middle', 2, true),
('b1000005-0000-4000-8000-000000000005', 'Free Delivery', 'On orders above 250', '/assets/banners/free-delivery.png', '/assets/banners/free-delivery-mobile.png', 'url', 'bottom', 1, true)
ON CONFLICT DO NOTHING;

-- =====================================================
-- 9. VENDOR SCHEDULES (for existing vendors)
-- =====================================================
INSERT INTO public.vendor_schedules (vendor_id, day_of_week, opening_time, closing_time, is_closed)
SELECT v.id, d.day, '08:00'::TIME, '22:00'::TIME, CASE WHEN d.day = 0 THEN true ELSE false END
FROM public.vendors v
CROSS JOIN (SELECT generate_series(0, 6) AS day) d
WHERE NOT EXISTS (
  SELECT 1 FROM public.vendor_schedules vs 
  WHERE vs.vendor_id = v.id AND vs.day_of_week = d.day
)
ON CONFLICT DO NOTHING;

-- =====================================================
-- 10. NOTIFICATION PREFERENCES (for existing users)
-- =====================================================
INSERT INTO public.notification_preferences (user_id, order_updates, subscription_alerts, promotional, review_requests, channel)
SELECT u.id, true, true, true, true, 'push'
FROM public.users u
WHERE NOT EXISTS (
  SELECT 1 FROM public.notification_preferences np WHERE np.user_id = u.id
)
ON CONFLICT DO NOTHING;

-- =====================================================
-- 11. SAMPLE REVIEWS (for existing vendors/orders)
-- =====================================================
INSERT INTO public.reviews (id, user_id, vendor_id, rating, comment, is_verified_purchase, status, helpful_count) 
SELECT 
  gen_random_uuid(),
  u.id,
  v.id,
  FLOOR(RANDOM() * 2 + 4)::INT,
  CASE FLOOR(RANDOM() * 5)::INT
    WHEN 0 THEN 'Great food! Loved the taste and portion size.'
    WHEN 1 THEN 'Quick delivery and fresh food. Highly recommended!'
    WHEN 2 THEN 'Healthy and delicious. Will order again.'
    WHEN 3 THEN 'Perfect for my fitness goals. Excellent protein content.'
    ELSE 'Good value for money. Fresh ingredients.'
  END,
  true,
  'published',
  FLOOR(RANDOM() * 20)::INT
FROM public.users u
CROSS JOIN public.vendors v
WHERE u.verified = true
LIMIT 15
ON CONFLICT DO NOTHING;

-- =====================================================
-- 12. SAMPLE NOTIFICATIONS
-- =====================================================
INSERT INTO public.notifications (user_id, type, title, message, data, is_read)
SELECT 
  u.id,
  'promo',
  'Welcome to Gutzo!',
  'Thanks for joining! Use code WELCOME50 for 50% off on your first order.',
  '{"coupon_code": "WELCOME50"}',
  false
FROM public.users u
WHERE NOT EXISTS (
  SELECT 1 FROM public.notifications n 
  WHERE n.user_id = u.id AND n.type = 'promo' AND n.title = 'Welcome to Gutzo!'
)
LIMIT 10
ON CONFLICT DO NOTHING;

-- =====================================================
-- 13. SAMPLE USER FAVORITES
-- =====================================================
INSERT INTO public.user_favorites (user_id, vendor_id, product_id)
SELECT 
  u.id,
  v.id,
  NULL
FROM public.users u
CROSS JOIN public.vendors v
WHERE u.verified = true AND v.is_active = true
LIMIT 10
ON CONFLICT DO NOTHING;

-- =====================================================
-- 14. SAMPLE SEARCH LOGS
-- =====================================================
INSERT INTO public.search_logs (query, results_count, device_type) VALUES
('protein bowl', 5, 'mobile'),
('chicken biryani', 8, 'mobile'),
('healthy breakfast', 12, 'web'),
('vegan salad', 3, 'mobile'),
('egg white omelette', 4, 'mobile'),
('low carb meals', 7, 'web'),
('grilled chicken', 6, 'mobile'),
('meal plan', 5, 'mobile'),
('weight loss food', 9, 'web'),
('high protein', 11, 'mobile')
ON CONFLICT DO NOTHING;

-- =====================================================
-- 15. SAMPLE ACTIVITY LOGS
-- =====================================================
INSERT INTO public.activity_logs (action, entity_type, metadata, device_type) VALUES
('app_open', 'app', '{"version": "1.0.0"}', 'mobile'),
('view_home', 'page', '{"source": "app_launch"}', 'mobile'),
('search', 'product', '{"query": "protein"}', 'mobile'),
('view_vendor', 'vendor', '{"vendor_name": "Daily Grub"}', 'mobile'),
('add_to_cart', 'product', '{"product_name": "Chicken Bowl"}', 'mobile'),
('checkout_started', 'order', '{"items_count": 2}', 'mobile'),
('payment_initiated', 'payment', '{"method": "upi"}', 'mobile'),
('order_placed', 'order', '{"order_value": 350}', 'mobile')
ON CONFLICT DO NOTHING;

-- =====================================================
-- 16. RIDERS (Sample delivery partners)
-- =====================================================
INSERT INTO public.riders (id, name, phone, vehicle_type, vehicle_number, active_status, is_verified, is_active) VALUES
('e1000001-0000-4000-8000-000000000001', 'Rajesh Kumar', '+919876543001', 'bike', 'TN39AB1234', 'online', true, true),
('e1000002-0000-4000-8000-000000000002', 'Suresh Babu', '+919876543002', 'scooter', 'TN39CD5678', 'online', true, true),
('e1000003-0000-4000-8000-000000000003', 'Karthik Raja', '+919876543003', 'bike', 'TN39EF9012', 'offline', true, true),
('e1000004-0000-4000-8000-000000000004', 'Murugan S', '+919876543004', 'scooter', 'TN39GH3456', 'busy', true, true),
('e1000005-0000-4000-8000-000000000005', 'Arun Kumar', '+919876543005', 'bike', 'TN39IJ7890', 'online', true, true)
ON CONFLICT DO NOTHING;

-- =====================================================
-- 17. WAITLIST (Sample entries)
-- =====================================================
INSERT INTO public.waitlist (type, target_id, user_phone, user_email, notified) VALUES
('zone', 'd1000001-0000-4000-8000-000000000001', '+919800000001', 'user1@example.com', false),
('zone', 'd1000002-0000-4000-8000-000000000002', '+919800000002', 'user2@example.com', false)
ON CONFLICT DO NOTHING;

-- =====================================================
-- 18. REFERRALS (Sample entries)
-- =====================================================
INSERT INTO public.referrals (referrer_id, referral_code, status, referrer_reward, referee_reward, expires_at)
SELECT 
  u.id,
  'REF' || UPPER(SUBSTRING(MD5(RANDOM()::TEXT) FROM 1 FOR 6)),
  'pending',
  50.00,
  50.00,
  NOW() + INTERVAL '30 days'
FROM public.users u
WHERE u.verified = true
LIMIT 5
ON CONFLICT DO NOTHING;

-- =====================================================
-- DONE! Verify counts
-- =====================================================
SELECT 'delivery_zones' as table_name, COUNT(*) as count FROM public.delivery_zones
UNION ALL SELECT 'vendor_delivery_zones', COUNT(*) FROM public.vendor_delivery_zones
UNION ALL SELECT 'product_variants', COUNT(*) FROM public.product_variants
UNION ALL SELECT 'product_addons', COUNT(*) FROM public.product_addons
UNION ALL SELECT 'coupons', COUNT(*) FROM public.coupons
UNION ALL SELECT 'meal_plans', COUNT(*) FROM public.meal_plans
UNION ALL SELECT 'meal_plan_day_menu', COUNT(*) FROM public.meal_plan_day_menu
UNION ALL SELECT 'promo_banners', COUNT(*) FROM public.promo_banners
UNION ALL SELECT 'vendor_schedules', COUNT(*) FROM public.vendor_schedules
UNION ALL SELECT 'reviews', COUNT(*) FROM public.reviews
UNION ALL SELECT 'notifications', COUNT(*) FROM public.notifications
UNION ALL SELECT 'notification_preferences', COUNT(*) FROM public.notification_preferences
UNION ALL SELECT 'user_favorites', COUNT(*) FROM public.user_favorites
UNION ALL SELECT 'search_logs', COUNT(*) FROM public.search_logs
UNION ALL SELECT 'activity_logs', COUNT(*) FROM public.activity_logs
UNION ALL SELECT 'riders', COUNT(*) FROM public.riders
UNION ALL SELECT 'waitlist', COUNT(*) FROM public.waitlist
UNION ALL SELECT 'referrals', COUNT(*) FROM public.referrals
ORDER BY table_name;
