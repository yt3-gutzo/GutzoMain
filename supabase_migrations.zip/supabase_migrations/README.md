# Gutzo Supabase Migration Guide

## How to Run

1. Open **Supabase Dashboard** → Your Project → **SQL Editor**
2. Run each batch **one by one** in order
3. Check for ✓ success after each batch

---

## Batch Order

| # | File                                | Tables | Description                                                   |
| - | ----------------------------------- | ------ | ------------------------------------------------------------- |
| 1 | `batch_1_location.sql`              | 3      | Delivery zones, vendor zones, riders                          |
| 2 | `batch_2_product_extras.sql`        | 2      | Product variants, addons                                      |
| 3 | `batch_3_payments.sql`              | 3      | Payments, coupons, coupon usage                               |
| 4 | `batch_4_meal_plans.sql`            | 3      | Meal plans, day menu, subscriptions                           |
| 5 | `batch_5_reviews_notifications.sql` | 4      | Reviews, votes, notifications, preferences                    |
| 6 | `batch_6_schedules_marketing.sql`   | 5      | Schedules, special hours, banners, referrals, waitlist        |
| 7 | `batch_7_support_analytics.sql`     | 6      | Tickets, favorites, search logs, activity, payouts, inventory |
| 8 | `batch_8_alter_existing.sql`        | -      | Add missing columns to existing tables                        |

---

## Total New Tables: 26

## Quick Commands

Copy file content to clipboard:

```bash
cat supabase_migrations/batch_1_location.sql | pbcopy
```

Then paste in Supabase SQL Editor and Run!
