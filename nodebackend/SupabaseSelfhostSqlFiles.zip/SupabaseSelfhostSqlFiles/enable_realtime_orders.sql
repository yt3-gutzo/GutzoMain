-- Enable Realtime for orders table
alter publication supabase_realtime add table orders;
