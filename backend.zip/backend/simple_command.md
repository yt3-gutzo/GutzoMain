caddy run --config /Users/MAHA/Desktop/GutzoMain/GutzoMain/backend/Caddyfile
deno run --allow-net --allow-env --env-file=backend/.env backend/index.ts
npm run dev
node backend/server.js


